Laser Scanner vs Barcodes
Juego web tipo Pac-Man donde un lector láser atrapa códigos de barras en movimiento. Incluye niveles progresivos, láser visual, sonido y formulario de contacto.